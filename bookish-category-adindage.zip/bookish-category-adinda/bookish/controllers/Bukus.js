const {Buku, Kategori} = require('../models');

// Fungsi untuk menampilkan semua Buku
const getAllBuku = async (req, res) => {
  try {
    const allBuku = await Buku.findAll();
    res.json(allBuku);
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
};

// Fungsi untuk menampilkan Buku berdasarkan ID
const getBukuById = async (req, res) => {
  const { id } = req.params;
  try {
    const bukuById = await Buku.findByPk(id);
    if (!bukuById) {
      return res.status(404).json({ status: 404, error: 'Buku not found' });
    }
    res.json(bukuById);
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
};

// Fungsi untuk membuat Buku baru
const createBuku = async (req, res) => {
  const { penulisId, penerbitId, kategoriId, judul, harga, isbn, tahunTerbit } = req.body;
  try {
    const newBuku = await Buku.create({ penulisId, penerbitId, kategoriId, judul, harga, isbn, tahunTerbit });
    res.status(201).json(newBuku);
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
};

// Fungsi untuk memperbarui Buku berdasarkan ID
const updateBuku = async (req, res) => {
  const { id } = req.params;
  const { penulisId, penerbitId, kategoriId, judul, harga, isbn, tahunTerbit } = req.body;
  try {
    const BukuToUpdate = await Buku.findByPk(id);
    if (!BukuToUpdate) {
      return res.status(404).json({ status: 404, error: 'Buku not found' });
    }
    await BukuToUpdate.update({ penulisId, penerbitId, kategoriId, judul, harga, isbn, tahunTerbit });
    res.json(BukuToUpdate);
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
};

// Fungsi untuk menghapus Buku berdasarkan ID
const deleteBuku = async (req, res) => {
  const { id } = req.params;
  try {
    const BukuToDelete = await Buku.findByPk(id);
    if (!BukuToDelete) {
      return res.status(404).json({ status: 404, error: 'Buku not found' });
    }
    await BukuToDelete.destroy();
    res.json({ message: 'Buku deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
};

// Fungsi untuk mengambil Buku berdasarkan kategori
const getBukuByKategori = async (req, res, next) => {
  try {
    const nama = req.params.nama;

    const booksByCategory = await Buku.findAll({
      include: [
        {
          model: Kategori,
          as: 'kategoris',
          where: {
            nama: nama,
          },
        },
      ],
    });

    if (booksByCategory.length === 0) {
      return res.status(404).json({ status: 404, error: 'Buku not found for the specified category' });
    }
    res.status(200).json({ status: 200, message: 'Success', data: booksByCategory });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, message: 'Internal Server Error', error: error.message });
  }
};

module.exports = {
  getAllBuku,
  getBukuById,
  createBuku,
  updateBuku,
  deleteBuku,
  getBukuByKategori,
};
