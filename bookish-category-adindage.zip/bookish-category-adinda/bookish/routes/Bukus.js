// routes/BukusRoutes.js

const express = require('express');
const router = express.Router();
const {getAllBuku, getBukuById, createBuku, updateBuku, deleteBuku, getBukuByKategori} = require('../controllers/Bukus');
const { authentication } = require('../middlewares/auth');

router.get('/', getAllBuku);
router.get('/:id', getBukuById);
router.post('/', authentication, createBuku);
router.put('/:id', authentication, updateBuku);
router.delete('/:id',authentication, deleteBuku);
router.get('/kategori/:nama', getBukuByKategori);

module.exports = router;
