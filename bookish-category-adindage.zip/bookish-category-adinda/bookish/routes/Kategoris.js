// routes/KategorisRoutes.js

const express = require('express');
const router = express.Router();
const {getAllKategoris, getKategorisById, createKategoris, updateKategoris, deleteKategoris} = require('../controllers/Kategoris');
const { authentication } = require('../middlewares/auth');

router.get('/', getAllKategoris);
router.get('/:id', getKategorisById);
router.post('/', authentication, createKategoris);
router.put('/:id',authentication, updateKategoris);
router.delete('/:id',authentication, deleteKategoris);

module.exports = router;
