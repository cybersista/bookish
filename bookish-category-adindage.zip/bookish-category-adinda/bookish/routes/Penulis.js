// routes/PenulisRoutes.js

const express = require('express');
const router = express.Router();
const {getAllPenulis,
    getPenulisById,
    createPenulis,
    updatePenulis,
    deletePenulis,} = require('../controllers/Penulis');
const { authentication } = require('../middlewares/auth');

router.get('/', getAllPenulis);
router.get('/:id',getPenulisById);
router.post('/', authentication, createPenulis);
router.put('/:id', authentication, updatePenulis);
router.delete('/:id',authentication, deletePenulis);

module.exports = router;
