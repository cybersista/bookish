// routes/PenerbitsRoutes.js

const express = require('express');
const router = express.Router();
const {getAllPenerbit,
    getPenerbitById,
    createPenerbit,
    updatePenerbit,
    deletePenerbit,} = require('../controllers/Penerbits');
const { authentication } = require('../middlewares/auth');

router.get('/', getAllPenerbit);
router.get('/:id', getPenerbitById);
router.post('/', authentication, createPenerbit);
router.put('/:id',authentication, updatePenerbit);
router.delete('/:id',authentication, deletePenerbit);

module.exports = router;
