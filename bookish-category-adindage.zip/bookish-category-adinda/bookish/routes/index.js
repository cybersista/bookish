const express       = require('express')
const router        = express.Router()
const path          = require('path')

/** Inisialisasi disini router kalian */
const userRoute = require('./user');
const BukusRoutes = require('./Bukus');
const KategorisRoutes = require('./Kategoris');
const PenerbitsRoutes = require('./Penerbits');
const PenulisRoutes = require('./Penulis');

router.get('/', (req,res) => {
    res.render('index',{
        title : 'Index',
        layout : 'layouts/main-layout'
    })
})
router.use('/user', userRoute);
router.use('/Buku', BukusRoutes);
router.use('/Kategori', KategorisRoutes);
router.use('/Penerbit', PenerbitsRoutes);
router.use('/Penulis', PenulisRoutes);

module.exports = router